// Mobile Navigation Toggle
const navToggle = document.querySelector(".nav-toggle")
const navMenu = document.querySelector(".nav-menu")

navToggle.addEventListener("click", () => {
  navMenu.classList.toggle("active")

  // Animate hamburger menu
  const bars = navToggle.querySelectorAll(".bar")
  bars.forEach((bar, index) => {
    if (navMenu.classList.contains("active")) {
      if (index === 0) bar.style.transform = "rotate(45deg) translate(5px, 5px)"
      if (index === 1) bar.style.opacity = "0"
      if (index === 2) bar.style.transform = "rotate(-45deg) translate(7px, -6px)"
    } else {
      bar.style.transform = "none"
      bar.style.opacity = "1"
    }
  })
})

// Close mobile menu when clicking on a link
document.querySelectorAll(".nav-link").forEach((link) => {
  link.addEventListener("click", () => {
    navMenu.classList.remove("active")
    const bars = navToggle.querySelectorAll(".bar")
    bars.forEach((bar) => {
      bar.style.transform = "none"
      bar.style.opacity = "1"
    })
  })
})

// Navbar scroll effect
window.addEventListener("scroll", () => {
  const navbar = document.querySelector(".navbar")
  if (window.scrollY > 100) {
    navbar.style.background = "rgba(255, 255, 255, 0.98)"
    navbar.style.boxShadow = "0 2px 20px rgba(0,0,0,0.1)"
  } else {
    navbar.style.background = "rgba(255, 255, 255, 0.95)"
    navbar.style.boxShadow = "none"
  }
})

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      const offsetTop = target.offsetTop - 80 // Account for fixed navbar
      window.scrollTo({
        top: offsetTop,
        behavior: "smooth",
      })
    }
  })
})

// Form submission handling
const contactForm = document.querySelector(".contact-form")
if (contactForm) {
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault()

    // Get form data
    const formData = new FormData(this)
    const formObject = {}
    formData.forEach((value, key) => {
      formObject[key] = value
    })

    // Show success message (you can replace this with actual form submission)
    showNotification("Pesan Anda berhasil dikirim! Kami akan segera menghubungi Anda.", "success")

    // Reset form
    this.reset()
  })
}

// Search form handling
const searchForm = document.querySelector(".search-form")
if (searchForm) {
  searchForm.addEventListener("submit", (e) => {
    e.preventDefault()
    showNotification("Pencarian sedang diproses...", "info")
    // Here you would typically handle the search functionality
  })
}

// Property card interactions
document.querySelectorAll(".property-card").forEach((card) => {
  const overlay = card.querySelector(".property-overlay")
  const button = overlay?.querySelector(".btn")

  if (button) {
    button.addEventListener("click", (e) => {
      e.stopPropagation()
      const propertyTitle = card.querySelector(".property-title").textContent
      showNotification(`Menampilkan detail untuk: ${propertyTitle}`, "info")
      // Here you would typically navigate to property detail page
    })
  }
})

// Notification system
function showNotification(message, type = "info") {
  // Remove existing notifications
  const existingNotifications = document.querySelectorAll(".notification")
  existingNotifications.forEach((notification) => notification.remove())

  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification notification-${type}`
  notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `

  // Add styles
  notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === "success" ? "#27ae60" : type === "error" ? "#e74c3c" : "#3498db"};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
    `

  // Add animation styles
  const style = document.createElement("style")
  style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        .notification-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }
        .notification-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 0;
            line-height: 1;
        }
        .notification-close:hover {
            opacity: 0.7;
        }
    `
  document.head.appendChild(style)

  // Add to page
  document.body.appendChild(notification)

  // Close button functionality
  const closeButton = notification.querySelector(".notification-close")
  closeButton.addEventListener("click", () => {
    notification.remove()
  })

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove()
    }
  }, 5000)
}

// Intersection Observer for animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -50px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.animation = "fadeInUp 0.6s ease forwards"
    }
  })
}, observerOptions)

// Observe elements for animation
document.addEventListener("DOMContentLoaded", () => {
  const animateElements = document.querySelectorAll(".property-card, .service-card, .contact-item")
  animateElements.forEach((el) => {
    el.style.opacity = "0"
    el.style.transform = "translateY(30px)"
    observer.observe(el)
  })
})

// Property filter functionality (if needed)
function filterProperties(type) {
  const properties = document.querySelectorAll(".property-card")
  properties.forEach((property) => {
    if (type === "all" || property.dataset.type === type) {
      property.style.display = "block"
    } else {
      property.style.display = "none"
    }
  })
}

// Back to top button
const backToTopButton = document.createElement("button")
backToTopButton.innerHTML = '<i class="fas fa-arrow-up"></i>'
backToTopButton.className = "back-to-top"
backToTopButton.style.cssText = `
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #f39c12, #e67e22);
    color: white;
    border: none;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.2rem;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
    z-index: 1000;
`

document.body.appendChild(backToTopButton)

// Show/hide back to top button
window.addEventListener("scroll", () => {
  if (window.scrollY > 300) {
    backToTopButton.style.opacity = "1"
    backToTopButton.style.visibility = "visible"
  } else {
    backToTopButton.style.opacity = "0"
    backToTopButton.style.visibility = "hidden"
  }
})

// Back to top functionality
backToTopButton.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  })
})

// Loading animation for images
document.addEventListener("DOMContentLoaded", () => {
  const images = document.querySelectorAll("img")
  images.forEach((img) => {
    img.addEventListener("load", () => {
      img.style.opacity = "1"
    })

    // Set initial opacity
    img.style.opacity = "0"
    img.style.transition = "opacity 0.3s ease"
  })
})

// Lazy loading for images (simple implementation)
const lazyImages = document.querySelectorAll("img[data-src]")
const imageObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      const img = entry.target
      img.src = img.dataset.src
      img.removeAttribute("data-src")
      imageObserver.unobserve(img)
    }
  })
})

lazyImages.forEach((img) => imageObserver.observe(img))

// Form validation
function validateForm(form) {
  const inputs = form.querySelectorAll("input[required], textarea[required], select[required]")
  let isValid = true

  inputs.forEach((input) => {
    if (!input.value.trim()) {
      input.style.borderColor = "#e74c3c"
      isValid = false
    } else {
      input.style.borderColor = "#27ae60"
    }
  })

  return isValid
}

// Add form validation to contact form
if (contactForm) {
  const inputs = contactForm.querySelectorAll("input, textarea, select")
  inputs.forEach((input) => {
    input.addEventListener("blur", () => {
      if (input.hasAttribute("required") && !input.value.trim()) {
        input.style.borderColor = "#e74c3c"
      } else {
        input.style.borderColor = "#27ae60"
      }
    })

    input.addEventListener("input", () => {
      if (input.style.borderColor === "rgb(231, 76, 60)" && input.value.trim()) {
        input.style.borderColor = "#27ae60"
      }
    })
  })
}

console.log("Uni Property website loaded successfully!")
